class CredentialLogger{

  var sysUserName = ""
  var sysPassword = ""

  object CredentialLogger {

    import scala.io.StdIn._

    def setUp(): Unit = {
      var doOnce = false

      var sysPromptUser = readLine("Please set your Username: ")
      var sysPromptPass = readLine("Please set your Password: ")

      do {
        sysUserName
        sysPromptPass

        doOnce = true
      } while (doOnce != true)

      sysUserName = sysPromptUser
      sysPassword = sysPromptPass

    }

    def prompt(): Unit = {


      println(
        s"""Hello, This is my first programming project that will log your website sign-in data for easy recall.
           |WARNING: Authentication required before proceeding.
           |""".stripMargin)

      println(sysUserName)
      println(sysPassword)

    }

    def main(args: Array[String]): Unit = {
      prompt()
      setUp()

    }
  }
}