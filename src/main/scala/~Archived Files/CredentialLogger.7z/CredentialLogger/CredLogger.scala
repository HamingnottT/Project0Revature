package CredentialLogger

import java.sql.{Connection, DriverManager, SQLException}
import java.io.File
import java.io.FileNotFoundException
import java.util.{InputMismatchException, Scanner}
import scala.io.StdIn._

object CredLogger {
  val driver = "com.mysql.jdbc.Driver"
  val url = "jdbc:mysql://localhost:3306/project0"
  val username = "root"
  val password = "RiffRaff68#$"
  val scanner = new Scanner(System.in)
  var connection:Connection = DriverManager.getConnection(url, username, password)

  val sysUserName = "HamingnottT"
  //var sysPassword = readLine("What is your Username? ")

  val msgMain =
    """--------------------------------
      |Returning results are in this order:
      |[Website] - [Username], [Password], [Email Address]
      |--------------------------------""".stripMargin
  val msgAdmin =
    """--------------------------------
      |Returning results are in this order:
      |[Row Index] - [Username], [Password]
      |--------------------------------""".stripMargin


  def website(): Unit = {
    println("\nWebsite option selected.\n")

    println(msgMain)

    CredLoggerQueries.getAllWebsites()





    /*
    lazy val continue = readLine("Continue [Y/N]? ")
    continue
    if (continue.toUpperCase == "Y")
      website()
    else println("Exiting Program...")
     */
  }
  /*
    def userName(): Unit ={

    }

    def email(): Unit ={

    }
  */
  //A way to show all users created in system
  def admin(): Unit ={
    lazy val adminLogin = readLine("Please Log in to continue: ")
    //lazy val showAllUsers = readLine("Show all Users? ")
    println("\n!!!Administrative Access Window!!!")
    adminLogin

    println(adminLogin)

  }

  def cancelProgram(): Unit = {
    println("Ending Program...")
  }
  //def setUp(): Unit = {}

  def main(args: Array[String]): Unit = {
    var mainMenuLoop = true

    println(s"""Hello, This is my first programming project that will log your website sign-in data for easy recall.
               |WARNING: Authentication required before proceeding.
               |""".stripMargin)

    println(f"Welcome in $sysUserName!\n")

    println(
      s"""Please input one of the numbers into the field below:
         |1 = Website | 2 = Username | 3 = Email | cxl = Cancel
         |""".stripMargin)

    do {
      var whereTo = readLine("What information are you looking for today? ")
      println()
      if (whereTo == "1") {
        website()
        mainMenuLoop = false
      } else if (whereTo == "2") {
        println("pending")
        mainMenuLoop = false
      } else if (whereTo == "3") {
        println("pending")
        mainMenuLoop = false
      } else if (whereTo.toLowerCase == "cxl") {
        cancelProgram()
        println()
        mainMenuLoop = false
      } else if (whereTo.toLowerCase == "admin") {
        admin()
      }
      else {
        println("Please enter a valid command.\n")
        whereTo = " "
      }
    } while (mainMenuLoop)
  }
  connection.close()
}
