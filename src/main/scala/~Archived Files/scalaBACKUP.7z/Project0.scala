

import java.sql.{Connection, DriverManager, SQLException}
import java.io.File
import java.io.FileNotFoundException
import java.util.{InputMismatchException, Scanner}
import scala.io.StdIn._
import TEST.GetData

object CredLogger {
  val driver = "com.mysql.jdbc.Driver"
  val url = "jdbc:mysql://localhost:3306/project0"
  val username = "root"
  val password = "RiffRaff68#$"
  val scanner = new Scanner(System.in)
  var connection:Connection = DriverManager.getConnection(url, username, password)

  val sysUserName = "HamingnottT"
  //var sysPassword = readLine("What is your Username? ")

  val msgMain =
    """--------------------------------
      |Returning results are in this order:
      |[Website] - [Username], [Password], [Email Address]
      |--------------------------------""".stripMargin
  val msgAdmin =
    """--------------------------------
      |Returning results are in this order:
      |[Row Index] - [Username], [Password]
      |--------------------------------""".stripMargin

  def getAllWebsites(): Unit ={
    val statement = connection.createStatement()
    statement.execute("use project0;")
    println(msgMain)
    println("\nReturning all websites of this application user:\n")
    val getAllSites = statement.executeQuery(f"SELECT website, username, password, email FROM project0.sql_user WHERE cl_user = '$sysUserName';")
    while ( getAllSites.next() ) {
      println(getAllSites.getString(1) + " - " + getAllSites.getString(2) + ", " + getAllSites.getString(3) + ", " + getAllSites.getString(4)) //testQuery1.getString(5), testQuery1.getString(6))
    }
  }

  def website(): Unit = {
    val statement = connection.createStatement()
    statement.execute("use project0;")
    def getAllWebsites(): Unit ={
      val statement = connection.createStatement()
      statement.execute("use project0;")
      println(msgMain)
      println("\nReturning all websites of this application user:\n")
      val getAllSites = statement.executeQuery(f"SELECT website, username, password, email FROM project0.sql_user WHERE cl_user = '$sysUserName';")
      while ( getAllSites.next() ) {
        println(getAllSites.getString(1) + " - " + getAllSites.getString(2) + ", " + getAllSites.getString(3) + ", " + getAllSites.getString(4)) //testQuery1.getString(5), testQuery1.getString(6))
      }
    }

    println("\nWebsite option selected.\n")

    getAllWebsites()




    /*
    lazy val continue = readLine("Continue [Y/N]? ")
    continue
    if (continue.toUpperCase == "Y")
      website()
    else println("Exiting Program...")
     */
  }
/*
  def userName(): Unit ={

  }

  def email(): Unit ={

  }
*/
  //A way to show all users created in system
  def admin(): Unit ={
    lazy val adminLogin = readLine("Please Log in to continue: ")
    //lazy val showAllUsers = readLine("Show all Users? ")
    println("\n!!!Administrative Access Window!!!")
    adminLogin

    println(adminLogin)

  }

  def cancelProgram(): Unit = {
    println("Ending Program...")
  }
  //def setUp(): Unit = {}

  def main(args: Array[String]): Unit = {
    var mainMenuLoop = true

    println(s"""Hello, This is my first programming project that will log your website sign-in data for easy recall.
               |WARNING: Authentication required before proceeding.
               |""".stripMargin)

    println(f"Welcome in $sysUserName!\n")

    println(
      s"""Please input one of the numbers into the field below:
         |1 = Website | 2 = Username | 3 = Email | cxl = Cancel
         |""".stripMargin)

    do {
      var whereTo = readLine("What information are you looking for today? ")
      println()
      if (whereTo == "1") {
        getAllWebsites()
        //website()
        mainMenuLoop = false
      } else if (whereTo == "2") {
        println("pending")
        mainMenuLoop = false
      } else if (whereTo == "3") {
        println("pending")
        mainMenuLoop = false
      } else if (whereTo.toLowerCase == "cxl") {
        cancelProgram()
        println()
        mainMenuLoop = false
      } else if (whereTo.toLowerCase == "admin") {
        admin()
      }
      else {
        println("Please enter a valid command.\n")
        whereTo = " "
      }
    } while (mainMenuLoop)
  }
  connection.close()
}
